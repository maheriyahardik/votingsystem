package com.example.votingapp;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;

public class HomeActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
    }

    public void onVoteClick(View view) {
        Intent intent = new Intent(this, VoteActivity.class);
        startActivity(intent);
    }

    public void onResultsClick(View view) {
        Intent intent = new Intent(this, ResultsActivity.class);
        startActivity(intent);
    }


    public void onViewAboutClick(View view) {
        Intent intent = new Intent(this, AboutActivity.class);
        startActivity(intent);
    }
    public void onAddAboutFeedback(View view) {
        Intent intent = new Intent(this, AddFeedbackActivity.class);
        startActivity(intent);
    }
    public void onViewFeedback(View view) {
        Intent intent = new Intent(this, ViewFeedbackActivity.class);
        startActivity(intent);
    }
    public void onViewHelp(View view) {
        Intent intent = new Intent(this, HelpActivity.class);
        startActivity(intent);
    }
    public void onViewTerms(View view) {
        Intent intent = new Intent(this, TermsActivity.class);
        startActivity(intent);
    }
}
