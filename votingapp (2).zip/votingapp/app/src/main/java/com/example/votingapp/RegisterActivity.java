package com.example.votingapp;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {
    private EditText usernameEditText, passwordEditText, enrollmentEditText; // Add enrollmentEditText
    private SQLiteDatabase db;
    private Button backToHomeButton, b3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        usernameEditText = findViewById(R.id.editText_username);
        passwordEditText = findViewById(R.id.editText_password);
        enrollmentEditText = findViewById(R.id.editText_enrollment); // Initialize enrollmentEditText
        backToHomeButton = findViewById(R.id.backTologintn);
        b3 = findViewById(R.id.button); // Reference to "Back to Home" button

        // Initialize the database
        db = openOrCreateDatabase("VotingAppDB", MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT, username VARCHAR UNIQUE, password VARCHAR, enrollment_number VARCHAR);"); // Add UNIQUE constraint to username

        // Set click listener for the "Back to Home" button
        backToHomeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to LoginActivity
                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(intent);
                finish(); // Optional: Close the current activity
            }
        });

        // Set click listener for another button (b3)
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to MainActivity
                Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                startActivity(intent);
                finish(); // Optional: Close the current activity
            }
        });
    }

    // Register logic with validation
    public void onRegister(View view) {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();
        String enrollmentNumber = enrollmentEditText.getText().toString().trim(); // Get the enrollment number

        // Validate that username, password, and enrollment number are not empty
        if (username.isEmpty()) {
            Toast.makeText(this, "Username cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }
        if (password.isEmpty()) {
            Toast.makeText(this, "Password cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }
        if (enrollmentNumber.isEmpty()) { // Validate enrollment number
            Toast.makeText(this, "Enrollment number cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validate enrollment number format (e.g., check if it's a 10-digit number)
        if (!isValidEnrollmentNumber(enrollmentNumber)) {
            Toast.makeText(this, "Invalid enrollment number. It should be 10 digits long.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if the username is unique
        if (!isUsernameUnique(username)) {
            Toast.makeText(this, "Username already taken. Please choose another.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Insert user credentials and enrollment number into the database
        db.execSQL("INSERT INTO users(username, password, enrollment_number) VALUES(?, ?, ?)", new String[]{username, password, enrollmentNumber});
        Toast.makeText(this, "Registered successfully", Toast.LENGTH_SHORT).show();

        // After successful registration, navigate to LoginActivity
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish(); // Optional: Close the current activity
    }

    // Method to validate enrollment number
    private boolean isValidEnrollmentNumber(String enrollmentNumber) {
        return enrollmentNumber.matches("\\d{10}"); // Change the regex based on your criteria
    }

    // Method to check if the username is unique
    private boolean isUsernameUnique(String username) {
        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE username = ?", new String[]{username});
        boolean isUnique = cursor.getCount() == 0; // Username is unique if count is 0
        cursor.close();
        return isUnique;
    }
}
