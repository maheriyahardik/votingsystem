package com.example.votingapp;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.database.Cursor;

import java.util.ArrayList;

public class ViewFeedbackActivity extends AppCompatActivity {

    ListView listViewFeedback;
    SQLiteDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_feedback);

        listViewFeedback = findViewById(R.id.listViewFeedback);

        // Open or create SQLite database
        database = openOrCreateDatabase("VotingAppDB", MODE_PRIVATE, null);

        // Fetch and display feedback
        fetchFeedback();
    }

    private void fetchFeedback() {
        ArrayList<String> feedbackList = new ArrayList<>();

        Cursor cursor = database.rawQuery("SELECT * FROM Feedback", null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                String feedback = cursor.getString(cursor.getColumnIndex("feedback"));
                feedbackList.add(feedback);
            }
            cursor.close();
        }

        if (feedbackList.isEmpty()) {
            Toast.makeText(this, "No feedback found", Toast.LENGTH_SHORT).show();
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, feedbackList);
        listViewFeedback.setAdapter(adapter);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (database != null) {
            database.close();
        }
    }
}
