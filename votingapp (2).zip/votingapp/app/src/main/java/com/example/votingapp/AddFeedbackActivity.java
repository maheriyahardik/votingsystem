package com.example.votingapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import android.database.sqlite.SQLiteDatabase;
import android.database.Cursor;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;

import androidx.appcompat.app.AppCompatActivity;

public class AddFeedbackActivity extends AppCompatActivity {

    EditText editTextFeedback;
    Button btnSubmitFeedback;
    SQLiteDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_feedback);

        editTextFeedback = findViewById(R.id.editTextFeedback);
        btnSubmitFeedback = findViewById(R.id.btnSubmitFeedback);

        // Initialize or create SQLite database
        database = openOrCreateDatabase("VotingAppDB", MODE_PRIVATE, null);
        createTableIfNotExists();

        btnSubmitFeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveFeedback();
            }
        });
    }

    private void createTableIfNotExists() {
        database.execSQL("CREATE TABLE IF NOT EXISTS Feedback(Id INTEGER PRIMARY KEY AUTOINCREMENT, feedback TEXT);");
    }

    private void saveFeedback() {
        String feedback = editTextFeedback.getText().toString().trim();

        if (feedback.isEmpty()) {
            Toast.makeText(this, "Please enter feedback", Toast.LENGTH_SHORT).show();
            return;
        }

        ContentValues contentValues = new ContentValues();
        contentValues.put("feedback", feedback);

        long result = database.insert("Feedback", null, contentValues);

        if (result != -1) {
            Toast.makeText(this, "Feedback submitted successfully", Toast.LENGTH_SHORT).show();
            editTextFeedback.setText("");
        } else {
            Toast.makeText(this, "Error submitting feedback", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (database != null) {
            database.close();
        }
    }
}
