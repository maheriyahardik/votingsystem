package com.example.votingapp;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.RadioButton;
import android.widget.Toast;

public class VoteActivity extends AppCompatActivity {
    private SQLiteDatabase db;
    private RadioButton candidate1, candidate2, candidate3, candidate4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vote);

        // Open or create database and tables for votes
        db = openOrCreateDatabase("VotingAppDB", MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS votes(id INTEGER PRIMARY KEY AUTOINCREMENT, candidate VARCHAR);");

        // Linking the radio buttons to the layout
        candidate1 = findViewById(R.id.radio_candidate1); // Candidate ABC
        candidate2 = findViewById(R.id.radio_candidate2); // Candidate XYZ
        candidate3 = findViewById(R.id.radio_candidate3); // Candidate 1
        candidate4 = findViewById(R.id.radio_candidate4); // Candidate 2
    }

    // This method handles the vote submission
    public void onVoteSubmit(View view) {
        String selectedCandidate = "";

        // Check which candidate is selected
        if (candidate1.isChecked()) {
            selectedCandidate = "Candidate rudra";
        } else if (candidate2.isChecked()) {
            selectedCandidate = "Candidate keyur";
        } else if (candidate3.isChecked()) {
            selectedCandidate = "Candidate shivam";
        } else if (candidate4.isChecked()) {
            selectedCandidate = "Candidate smit";
        } else {
            Toast.makeText(this, "Please select a candidate.", Toast.LENGTH_SHORT).show();


        return; // Exit if no candidate is selected
        }

        // Insert the vote into the votes table without validating if the user has voted before
        ContentValues values = new ContentValues();
        values.put("candidate", selectedCandidate);
        db.insert("votes", null, values);

        // Show confirmation message
        Toast.makeText(this, "Vote submitted for " + selectedCandidate, Toast.LENGTH_SHORT).show();


        // Optionally, clear the radio button selection after voting
        clearRadioButtonSelection();
    }

    // Helper method to clear the radio button selection
    private void clearRadioButtonSelection() {
        candidate1.setChecked(false);
        candidate2.setChecked(false);
        candidate3.setChecked(false);
        candidate4.setChecked(false);
        this.finish();

    }
}
