package com.example.votingapp;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.TextView;

public class ResultsActivity extends AppCompatActivity {
    private SQLiteDatabase db;
    private TextView resultsTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);

        resultsTextView = findViewById(R.id.textView_results);
        db = openOrCreateDatabase("VotingAppDB", MODE_PRIVATE, null);

        Cursor cursor = db.rawQuery("SELECT candidate, COUNT(candidate) AS votes FROM votes GROUP BY candidate", null);
        StringBuilder results = new StringBuilder();
        while (cursor.moveToNext()) {
            String candidate = cursor.getString(0);
            int voteCount = cursor.getInt(1);
            results.append(candidate).append(": ").append(voteCount).append(" votes\n");
        }

        resultsTextView.setText(results.toString());
    }
}
