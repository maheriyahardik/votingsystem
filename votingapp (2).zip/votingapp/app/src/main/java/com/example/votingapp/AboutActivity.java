package com.example.votingapp;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class AboutActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        TextView aboutTextView = findViewById(R.id.textView_about);
        aboutTextView.setText(getAboutText());
    }

    private String getAboutText() {
        return "About Voting App\n\n" +
                "This app allows users to vote on various issues and view results.\n\n" +
                "Features:\n" +
                "- User Registration: Create a new account to participate in voting.\n" +
                "- Secure Login: Access your account with a username and password.\n" +
                "- Voting Interface: Simple and intuitive interface for your votes.\n" +
                "- Real-time Results: View the results of ongoing votes instantly.\n" +
                "- Feedback: Share your thoughts and suggestions for app improvement.\n\n" +
                "Developed by Your Name.\n" +
                "Contact: keyur@gmail.com\n" +
                "Contact: shivam@gmail.com.com\n" +
                "Contact: hardik@gmail.com\n" +
                "Version: 1.0\n" +
                "Last updated: October 2024\n" +
                "Thank you for using the Voting App!";
    }
}
